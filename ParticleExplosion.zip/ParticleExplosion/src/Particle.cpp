/*
 * Particles.cpp

 *
 *  Created on: Jan 18, 2018
 *      Author: lanlex
 */
#define  SDL_MAIN_HANDLED

#include "Particle.h"
#include <math.h>

#include <stdlib.h> // to use RAN function

namespace caveofprogramming {

Particle::Particle() :
		m_x(0), m_y(0) {

	init();
	//to fit range -1 to +1
	//m_x = ((2.0*rand())/RAND_MAX) - 1;
	//m_y = ((2.0*rand())/RAND_MAX) - 1;

	//make xspeed to be both negative and postive +1 and -1 by doing -1 behind
	//2.0 * rand the .0 gives a double value and 2 increase the range
	//*0.01 is the speed of change

	//m_xspeed = 0.001 * (((2.0*rand())/RAND_MAX)-1);
	//m_yspeed = 0.001 * (((2.0*rand())/RAND_MAX)-1);
}

Particle::~Particle() {
	// TODO Auto-generated destructor stub
}

void Particle::init() {
	m_x = 0;
	m_y = 0;

	m_direction = (2 * M_PI * rand()) / RAND_MAX;
	m_speed = (0.04 * rand()) / RAND_MAX;

	//by squaring, the average distance between particles increases as you go from inner edge to outer edge instead of linearly
	m_speed *= m_speed;

}

void Particle::update(int interval) {

	//make particles curl around abit in direction
	m_direction += interval * 0.0003;

	double xspeed = m_speed * cos(m_direction);
	double yspeed = m_speed * sin(m_direction);

	m_x += xspeed * interval;
	m_y += yspeed * interval;

	if (m_x < -1 || m_x > 1 || m_y < -1 || m_y > 1) {
		init();
	}

	if (rand() < RAND_MAX / 100) {
		init();
	}
	/*	m_x += m_xspeed;
	 m_y += m_yspeed;

	 if(m_x<0-1.0||m_x>=1.0)
	 {
	 m_xspeed= -m_xspeed;
	 }
	 if(m_x<0-1.0||m_x>=1.0)
	 {
	 m_yspeed= -m_yspeed;
	 }
	 */

}

} /* namespace caveofprogramming */
