/*
 * Particles.h
 *
 *  Created on: Jan 18, 2018
 *      Author: lanlex
 */
#define  SDL_MAIN_HANDLED
#ifndef PARTICLE_H_
#define PARTICLE_H_

namespace caveofprogramming {

//only difference between struct and class is by default members variables are public in struct when not declared
struct Particle {

	//coordinates, change the values gradually bit by bit so use double
	double m_x;
	double m_y;

	//	double m_xspeed;
	//	double m_yspeed;
private:
	double m_speed;
	double m_direction;

private:
	void init();

public:
	Particle();
	virtual ~Particle();
	void update(int interval);
};

} /* namespace caveofprogramming */

#endif /* PARTICLE_H_ */
