//============================================================================
// Name        : SDL.cpp
// Author      : John Purcell
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#define  SDL_MAIN_HANDLED

#include <iostream>

#include <string.h>
#include <SDL.h>
#include <math.h>
#include "Screen.h"
#include "Swarm.h"
#include <stdlib.h> //for srand function
#include <time.h> //for time()
using namespace std;
using namespace caveofprogramming;

int main() {

	//random number generator
	srand(time(NULL));

	Screen screen;

	if (screen.init() == false) {
		cout << "Error initialising SDL." << endl;
	}

	Swarm swarm;

	while (true) {
		// Update particles
		// Draw particles
		//Since redraw the screen every 30 times per second, we can move the particles in between redraws by clearing the screen

		//Animating Colors
		//get milliseconds
		int elapsed = SDL_GetTicks();

		//screen.clear();
		//Pass in elaspsed time to ensure constant speed of explosion in differnet pcs of differnet processing speed
		swarm.update(elapsed);

		//sin is within a range of +1 and -1, can produce nice smooth color change
		unsigned char green =
				(unsigned char) ((1 + sin(elapsed * 0.0001)) * 128);
		unsigned char red = (unsigned char) ((1 + sin(elapsed * 0.0002)) * 128);
		unsigned char blue = (unsigned char) ((1 + sin(elapsed * 0.0003)) * 128);

		//can use cosine value as well but range of 0 to +1

		const Particle * const pParticles = swarm.getParticles();

		for (int i = 0; i < Swarm::NPARTICLES; i++) {
			Particle particle = pParticles[i];
			// +1 to go from 0 to 2 instead of -1 to +1 * half of screen to be center
			int x = (particle.m_x + 1) * Screen::SCREEN_WIDTH / 2;
			int y = particle.m_y * Screen::SCREEN_WIDTH / 2
					+ Screen::SCREEN_HEIGHT / 2;

			screen.setPixel(x, y, red, green, blue);

		}

		/* Not used anymore
		 //loop top row down
		 for(int y=0; y < Screen::SCREEN_HEIGHT; y++) {
		 //loop left column right
		 for(int x=0; x < Screen::SCREEN_WIDTH; x++) {
		 screen.setPixel(x, y, red, green, blue);
		 }
		 }
		 */

		//many ways to implement this blur
		screen.boxBlur();

		// Draw the screen
		screen.update();

		// Check for messages/events
		if (screen.processEvents() == false) {
			break;
		}
	}

	screen.close();

	return 0;
}
